package com.example.empoweringthenation

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.registrationapp.Register

class CourseSelection : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_course_selection)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val firstAidButton = findViewById<Button>(R.id.firstAidButton)
        val sewingButton = findViewById<Button>(R.id.sewingButton)
        val landscapingButton = findViewById<Button>(R.id.landscapingButton)
        val lifeSkillsButton = findViewById<Button>(R.id.lifeSkillsButton)
        val childMindingButton = findViewById<Button>(R.id.childMindingButton)
        val cookingButton = findViewById<Button>(R.id.cookingButton)
        val gardenMaintenanceButton = findViewById<Button>(R.id.gardenMaintenanceButton)
        val registerButton3 =  findViewById<Button>(R.id.registerButton3)
        val backButton = findViewById<Button>(R.id.backButton)

        firstAidButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        sewingButton.setOnClickListener {
                // Intent to move from MainActivity to NextActivity
                val intent = Intent(this@CourseSelection, Register::class.java)
                startActivity(intent) }

        landscapingButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        lifeSkillsButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        childMindingButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        cookingButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        gardenMaintenanceButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        registerButton3.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, Register::class.java)
            startActivity(intent) }

        backButton.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@CourseSelection, MainActivity2::class.java)
            startActivity(intent) }


    }
}