package com.example.empoweringthenation

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val aboutUs = findViewById<Button>(R.id.aboutButton)
        val skillsInfoButton = findViewById<Button>(R.id.skillsInfoButton)
        val courseButton = findViewById<Button>(R.id.courseButton)
        val backButton = findViewById<Button>(R.id.backButton)

        aboutUs.setOnClickListener {
            // Intent to move from MainActivity to NextActivity
            val intent = Intent(this@MainActivity2, AboutUs::class.java)
            startActivity(intent) }

            skillsInfoButton.setOnClickListener {
                // Intent to move from MainActivity to NextActivity
                val intent = Intent(this@MainActivity2, SkillsInfo::class.java)
                startActivity(intent) }

                courseButton.setOnClickListener {
                    // Intent to move from MainActivity to NextActivity
                    val intent = Intent(this@MainActivity2, CourseSelection::class.java)
                    startActivity(intent) }

                    backButton.setOnClickListener {
                        // Intent to move from MainActivity to NextActivity
                        val intent = Intent(this@MainActivity2, MainActivity::class.java)
                        startActivity(intent)
                    }
                }
}